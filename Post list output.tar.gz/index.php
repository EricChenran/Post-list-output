<?php
$link=mysqli_connect('localhost','数据库名称','数据库账号','数据库密码');
$find=mysqli_query($link,"SELECT * FROM page order by id");
//$result=mysqli_fetch_array($find);
//$result2=array("id"=>$result['id'],"title"=>$result['tile'],"内容"=>$result['content'],"时间"=>$result['time']);
//print_r(json_encode($result2));

?>
<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="https://www.layuicdn.com/layui/css/layui.css" />
  </head>

  <body>
      <table class="layui-table">
  <colgroup>
    <col width="150">
    <col width="200">
    <col>
  </colgroup>
  <thead>
    <tr>
      <th>id</th>
      <th>title</th>
      <th>内容</th>
      <th>时间</th>
    </tr> 
  </thead>
  <tbody>
         <?while ($result=mysqli_fetch_array($find)){
             echo "<tr>";
    echo "<td>".$result['id']."</td>";
        echo "<td>".$result['tile']."</td>";
    echo "<td>".$result['content']."</td>";
    echo "<td>".$result['time']."</td>";
             echo "</tr>";

}?>
    
    </tr>
  </tbody>
</table>
      
     
      
    <script src="https://www.layuicdn.com/layui/layui.js"></script>
    <!--您的Layui代码start-->
  </body>

</html>
